# VORP-Hunting
- hunt animals and sell 
- sell big fish
- whole animals
- carcasses
- pelts
- pelts stored on the back of the horses
- NEW you can get items to inventory when skinning them.

 ## Improvements
* New Leveling System 
Level 1(200-400xp): 
+$5.00 per Animal Hide
+25% per Animal Carcass
Level 2(400-700xp):
+$7.00 per Animal Hide
+50% per Animal Carcass
Purchase Lower Baits
Level 3(700-900xp) : 
+$10.00 per Animal Hide
+75% per Animal Carcass
Unique Weapon
Level 4(900-1400xp):
+$12.00 per Animal Hide
+100% per Animal Carcass
Craft Baits / Purchase HQ Bait
Level 5(1400-2200xp):
+$15.00 per Animal Hide
+125% per Animal Carcass
Craft HQ Bait
Access to Certain Wardrobe pieces?
Level 6(2200xp+):
+$20.00 per Animal Hide
+150% per Animal Carcass
Access to some type of Large Rifle
Craft Legendary Bait

* Increased base amount you make from pelts and carcass, price also increases per level
* Legendary Pelts will be able to be sold for a good profit now
* New Bait System based on Level
* Baits: Carnivore Bait | Potent Carnivore Bait | Herbivore Bait | Potent Herbivore Bait | Legendary Bait | Bird Bait?
* Bait system on 1 minute cooldown to prevent spam spawning.
* Bait system cannot be used near a town, this is to prevent players from baiting in predatory animals.
* Bait system spawns a random animal from a configurable table. 
* Each bait used will spawn (1-2?)an animal in. 
* This animal will spawn away from the player, then the animal will start to head towards the location of the bait placed down.
* Created Legendary Bait item to be able to bait Legendary Animals.
* Created a command /huntinglvl Displays Current Lvl as well as XP till next Lvl.

## Install
*Add script into resources folder.
Step 1) Run Sql Query on database (included in hunting.sql);
Step 2) Add the image from images folder into vorp_inventory/html/img/items. This will allow the image to display for Legendary Bait in the inventory.
Step 3) Restart server or wait for restart.
Step 4) Done.